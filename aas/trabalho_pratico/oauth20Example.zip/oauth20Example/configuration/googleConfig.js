module.exports = {
  api_key: "yourKey.apps.googleusercontent.com",
  api_secret: "secretKey",
  callback_url: "http://localhost:3000/auth/google/callback",
};
