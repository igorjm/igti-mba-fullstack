module.exports = {
  clientID: "274110417446122",
  clientSecret: "2483fd04686fcefe024bc3734ce1660e",
  callbackURL: "http://localhost:3000/auth/facebook/callback/",
};
