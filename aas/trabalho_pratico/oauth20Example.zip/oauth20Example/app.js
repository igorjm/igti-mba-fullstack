// Igor José Melo
// Sadu Toledo de Souza
// Luis Vinicius Costa Damaceno
// Vinícius Lima e Sena
// Tiago Gerevini Yoshioka

const express = require("express"),
  passport = require("passport"),
  FacebookStrategy = require("passport-facebook").Strategy,
  cookieParser = require("cookie-parser"),
  session = require("express-session"),
  bodyParser = require("body-parser"),
  googleConfig = require("./configuration/googleConfig"),
  facebookConfig = require("./configuration/facebookConfig"),
  app = express();

var GoogleStrategy = require("passport-google-oauth20").Strategy;

// Google Authentication
passport.use(
  new GoogleStrategy(
    {
      clientID: googleConfig.api_key,
      clientSecret: googleConfig.api_secret,
      callbackURL: googleConfig.callback_url,
    },
    function (accessToken, refreshToken, profile, done) {
      return done(null, profile);
    }
  )
);

// Facebook Authentication
passport.use(
  new FacebookStrategy(
    {
      clientID: facebookConfig.clientID,
      clientSecret: facebookConfig.clientSecret,
      callbackURL: facebookConfig.callbackURL,
    },
    function (accessToken, refreshToken, profile, done) {
      return done(null, profile);
    }
  )
);

// Passport session setup.
passport.serializeUser(function (user, done) {
  done(null, user);
});

passport.deserializeUser(function (obj, done) {
  done(null, obj);
});

app.set("views", __dirname + "/views");
app.set("view engine", "ejs");
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  session({ secret: "keyboard cat", resave: true, saveUninitialized: true })
);
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static(__dirname + "/public"));

app.get("/", function (req, res) {
  console.log("req.user:", req.user);
  res.render("index", { user: req.user });
});

// Google
app.get(
  "/auth/google",
  passport.authenticate("google", { scope: ["profile"] })
);

app.get(
  "/auth/google/callback",
  passport.authenticate("google", {
    successRedirect: "/",
    failureRedirect: "/login",
  }),
  function (req, res) {
    res.redirect("/");
  }
);

// Facebook
app.get(
  "/auth/facebook",
  passport.authenticate("facebook", {
    scope: "email",
  })
);

app.get(
  "/auth/facebook/callback",
  passport.authenticate("facebook", {
    successRedirect: "/",
    failureRedirect: "/login",
  }),
  function (req, res) {
    res.redirect("/");
  }
);

app.get("/logout", function (req, res) {
  req.logout();
  res.redirect("/");
});

app.listen(3000, () => console.log("Server up"));
